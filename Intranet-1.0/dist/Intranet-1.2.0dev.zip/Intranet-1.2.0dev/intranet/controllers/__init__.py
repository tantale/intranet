# -*- coding: utf-8 -*-
"""
:package: intranet.controllers
:date: 2013-07-28
:author: Laurent LAPORTE <sandlol2009@gmail.com>

Controllers for the Intranet application.
"""

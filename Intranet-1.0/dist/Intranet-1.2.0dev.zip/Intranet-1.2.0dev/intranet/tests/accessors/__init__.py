"""
:package: intranet.tests.accessors
:date: 2013-10-11
:author: Laurent LAPORTE <sandlol2009@gmail.com>
"""

"""
:package: intranet.model.pointage
:date: 2013-08-10
"""



# -*- coding: utf-8 -*-
"""The Intranet package"""

"""
:package: intranet.templates.pointage.chart
:date: 2013-10-19
:author: Laurent LAPORTE <sandlol2009@gmail.com>
"""

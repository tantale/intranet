"""
:package: intranet.templates.pointage.order
:date: 2013-08-11
"""

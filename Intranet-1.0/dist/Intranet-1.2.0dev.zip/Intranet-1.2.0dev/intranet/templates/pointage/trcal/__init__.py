"""
:package: intranet.templates.pointage.trcal
:date: 2013-09-22
:author: Laurent LAPORTE <sandlol2009@gmail.com>
"""

"""
:package: intranet.templates.tools
:date: 2014-01-24
:author: Laurent LAPORTE <sandlol2009@gmail.com>
"""

# -*- coding: utf-8 -*-
"""
Package: intranet.lib
Created on 2012-10-11
Intranet Libraries.
"""
